        @stack('footer')
        <script type="text/javascript" src="{{ asset('files/assets/js/jquery-2.1.1.js')}}"></script>
        <script type="text/javascript" src="{{ asset('files/assets/js/bootstrap.min.js')}}"></script>
        <script type="text/javascript" src="{{ asset('files/assets/js/plugins.js')}}"></script>
        <script type="text/javascript" src="{{ asset('files/assets/js/menu.js')}}"></script>
        <script type="text/javascript" src="{{ asset('files/assets/js/custom.js')}}"></script>
        @yield('footer')
