        <meta charset="utf-8">
        <title>Qoryah Qur'an</title>
        <!-- Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Mencetak One Hafidz For One Masjid">
        <meta name="keywords" content="Qoryah Qur'an">
        <!-- Favicon icon -->
        <link rel="icon" href="{{ asset('img/icon.png') }}" type="image/png" sizes="16x16">
        <!-- Bootstrap -->
        <link rel="stylesheet" type="text/css" href="{{ asset('files/assets/css/bootstrap.min.css')}}" media="all" />
        <!-- Font Awesome -->
        <link rel="stylesheet" type="text/css" href="{{ asset('files/assets/icon/font-awesome/css/font-awesome.min.css')}}">
        <link rel="stylesheet" type="text/css" href="{{ asset('files/assets/pages/social-timeline/timeline.css')}}">
        <!-- ico font -->
        <link rel="stylesheet" type="text/css" href="{{ asset('files/assets/icon/icofont/css/icofont.css')}}">
        <!-- Animate CSS -->
        <link rel="stylesheet" type="text/css" href="{{ asset('files/assets/css/animate.css')}}">
        <!-- Owl Carousel -->
        <link rel="stylesheet" type="text/css" href="{{ asset('files/assets/css/owl.carousel.css')}}">
        <link rel="stylesheet" type="text/css" href="{{ asset('files/assets/css/owl.theme.css')}}">
        <!-- Magnific Popup -->
        <link rel="stylesheet" type="text/css" href="{{ asset('files/assets/css/magnific-popup.css')}}">
        <!-- Full Page Animation -->
        <link rel="stylesheet" type="text/css" href="{{ asset('files/assets/css/animsition.min.css')}}">
        <!-- Ionic Icons -->
        <link rel="stylesheet" type="text/css" href="{{ asset('files/assets/css/ionicons.min.css')}}">
        <!-- Material Icon -->
        <link rel="stylesheet" type="text/css" href="{{ asset('files/assets/icon/material-design/css/material-design-iconic-font.min.css')}}">
        <!-- General SCSS -->
        <link rel="stylesheet" type="text/css" href="{{ asset('files/assets/scss/partials/_general.scss')}}">
        <!-- Main Style css -->
        <link rel="stylesheet" type="text/css" href="{{ asset('files/assets/css/style.css')}}" media="all" />
        <link rel="stylesheet" type="text/css" href="{{ asset('css/adn.css')}}" media="all" />
        @stack('header')
