@component('templates.widgets')
    @slot('header')
    <link rel="stylesheet" type="text/css" href="{{ asset('files/assets/pages/message/message.css')}}">
    @endslot
    @slot('footer')
    @endslot
@endcomponent

