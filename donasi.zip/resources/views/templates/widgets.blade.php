@push('header')
{{ $header }}
@endpush
@push('footer')
{{ $footer }}
@endpush
