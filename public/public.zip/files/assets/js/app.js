function respon(tipe,judul,isi){
    Swal.fire({
        type: tipe,
        title: judul,
        text: isi,
    })
}