        <script type="text/javascript" src="{{ asset('files/bower_components/jquery/js/jquery.min.js')}}"></script>
        <script type="text/javascript" src="{{ asset('files/bower_components/jquery-ui/js/jquery-ui.min.js')}}"></script>
        <script type="text/javascript" src="{{ asset('files/bower_components/bootstrap/js/bootstrap.min.js')}}"></script>
        <script type="text/javascript" src="{{ asset('files/assets/pages/waves/js/waves.min.js')}}"></script>
        <script type="text/javascript" src="{{ asset('files/bower_components/jquery-slimscroll/js/jquery.slimscroll.js')}}"></script>
        <script type="text/javascript" src="{{ asset('files/bower_components/modernizr/js/modernizr.js')}}"></script>
        <script type="text/javascript" src="{{ asset('files/bower_components/modernizr/js/css-scrollbars.js')}}"></script>
        <script type="text/javascript" src="{{ asset('files/assets/pages/j-pro/js/jquery.ui.min.js')}}"></script>
        <script type="text/javascript" src="{{ asset('files/assets/pages/j-pro/js/jquery.maskedinput.min.js')}}"></script>
        <script type="text/javascript" src="{{ asset('files/assets/pages/j-pro/js/jquery.j-pro.js')}}"></script>
        
        @stack('footer')
        <script type="text/javascript" src="{{ asset('files/assets/js/jquery-2.1.1.js')}}"></script>
        <script type="text/javascript" src="{{ asset('files/assets/js/bootstrap.min.js')}}"></script>
        <script type="text/javascript" src="{{ asset('files/assets/js/plugins.js')}}"></script>
        <script type="text/javascript" src="{{ asset('files/assets/js/menu.js')}}"></script>
        <script type="text/javascript" src="{{ asset('files/assets/js/custom.js')}}"></script>
        @yield('footer')
