@component('templates.widgets')
    @slot('header')
    @endslot
    @slot('footer')
    <!-- FORM MASK -->
    <script type="text/javascript" src="{{ asset('files/assets/pages/form-masking/jquery.mask.js')}}"></script>
    @endslot
@endcomponent

