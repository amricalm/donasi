@component('templates/widgets')
    @slot('header')

    @endslot
    @slot('footer')

    @endslot
@endcomponent
